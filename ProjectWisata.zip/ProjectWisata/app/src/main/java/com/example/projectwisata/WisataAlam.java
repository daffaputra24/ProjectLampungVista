package com.example.projectwisata;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;

public class WisataAlam extends AppCompatActivity {
    ListView listView;
    SimpleAdapter adapter;
    HashMap<String, String> map;
    ArrayList<HashMap<String, String>> mylist;
    String[] jdl; //deklarasi judul iem
    String[] ktr; //deklarasi keterangan item
    String[] img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wisata_alam);

        listView = (ListView) findViewById(R.id.list);
        jdl = new String[]{"Teluk Kiluan", "Taman Nasional Way Kambas",
                "Pantai Dewi Mandapa", "Curup Gangsa ","Air Terjun Ciupang",
                "Air Terjun Putri Malu","Bukit BLT","Bukit Pangonan", "Bukit Batu","Pantai Gigi Hiu"

        };

        ktr = new String[]{"Kab.Tanggamus", "Kab.Lampung Timur",
                "Kab.Pesawaran", "Kab.Way Kanan","Kab.Pesawaran",
                "Kab.Way Kanan","Kab.Pringsewu","Kab.Pringsewu", "Kab.Lampung Selatan","Kab.Tangamus"
        };

        img = new String[]{Integer.toString(R.drawable.telukkiluan), Integer.toString(R.drawable.waykambas), Integer.toString(R.drawable.pantaidewi),
                Integer.toString(R.drawable.curupgangsa), Integer.toString(R.drawable.airterjunciupang), Integer.toString(R.drawable.airterjunputrimalu),
                Integer.toString(R.drawable.bukitblt), Integer.toString(R.drawable.bukitpangonan), Integer.toString(R.drawable.bukitbatu),
                Integer.toString(R.drawable.pantaigigihiu)
        };

        mylist = new ArrayList<HashMap<String, String>>();

        for (int i=0; i<jdl.length; i++){
            map = new HashMap<String, String>();
            map.put("judul", jdl[i]);
            map.put("Keterangan", ktr[i]);
            map.put("Gambar", img[i]);
            mylist.add(map);
        }
        adapter = new SimpleAdapter(this, mylist, R.layout.list_wisata,
                new String[]{"judul", "Keterangan", "Gambar"}, new int[]{R.id.txt_judul,(R.id.txt_keterangan),(R.id.img)});
        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                if (position == 0) {
                    Intent myIntent = new Intent(view.getContext(), TelukKiluan.class);
                    startActivityForResult(myIntent, 0);
                }

                if (position == 1) {
                    Intent myIntent = new Intent(view.getContext(), WayKambas.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 2) {
                    Intent myIntent = new Intent(view.getContext(), PantaiDewi.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 3) {
                    Intent myIntent = new Intent(view.getContext(), CurupGangsa.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 4) {
                    Intent myIntent = new Intent(view.getContext(), AirTerjunCiupang.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 5) {
                    Intent myIntent = new Intent(view.getContext(), AirTerjunPutri.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 6) {
                    Intent myIntent = new Intent(view.getContext(), BukitBlt.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 7) {
                    Intent myIntent = new Intent(view.getContext(), BukitPangonan.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 8) {
                    Intent myIntent = new Intent(view.getContext(), BukitBatu.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 9) {
                    Intent myIntent = new Intent(view.getContext(), PantaiGigiHiu.class);
                    startActivityForResult(myIntent, 0);
                }


            }
        });
    }
}