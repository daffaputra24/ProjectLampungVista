package com.example.projectwisata;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;

public class Penginapan extends AppCompatActivity {
    ListView listView;
    SimpleAdapter adapter;
    HashMap<String, String> map;
    ArrayList<HashMap<String, String>> mylist;
    String[] jdl; //deklarasi judul iem
    String[] ktr; //deklarasi keterangan item
    String[] img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_penginapan);

        listView = (ListView) findViewById(R.id.listPenginapan);
        jdl = new String[]{"Villa Andreas Pahawang", "Pulau Tegal Mas",
                "Grand Elty Krakatoa", "Lovina Krui Resort","Nariska Suite Homestay"
        };

        ktr = new String[]{"Kab.Pesawaran", "Kab.Pesawaran",
                "Kab.Lampung Selatan", "Kab.Pesisir Barat","Kota Bandar Lampung"
        };

        img = new String[]{Integer.toString(R.drawable.villaandreas), Integer.toString(R.drawable.pulautegasmas), Integer.toString(R.drawable.grandelty),
                Integer.toString(R.drawable.lovinakrui), Integer.toString(R.drawable.nariskasuite)
        };

        mylist = new ArrayList<HashMap<String, String>>();

        for (int i=0; i<jdl.length; i++){
            map = new HashMap<String, String>();
            map.put("judul", jdl[i]);
            map.put("Keterangan", ktr[i]);
            map.put("Gambar", img[i]);
            mylist.add(map);
        }
        adapter = new SimpleAdapter(this, mylist, R.layout.list_penginapan,
                new String[]{"judul", "Keterangan", "Gambar"}, new int[]{R.id.txt_judul,(R.id.txt_keterangan),(R.id.img)});
        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                if (position == 0) {
                    Intent myIntent = new Intent(view.getContext(), VillaAndreas.class);
                    startActivityForResult(myIntent, 0);
                }

                if (position == 1) {
                    Intent myIntent = new Intent(view.getContext(), PulauTegalMas.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 2) {
                    Intent myIntent = new Intent(view.getContext(), GrandElty.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 3) {
                    Intent myIntent = new Intent(view.getContext(), LovinaKrui.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 4) {
                    Intent myIntent = new Intent(view.getContext(), NariskaSuite.class);
                    startActivityForResult(myIntent, 0);
                }

            }
        });
    }
}